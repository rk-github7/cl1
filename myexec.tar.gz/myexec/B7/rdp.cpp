/*
E->TE'
E'->+TE'|eps
T->FT'
T'->*FT'|eps
F->(E)|id  */

#include<iostream>
#include<string.h>
#include<ctype.h>
using namespace std;
int i=0,error=0;
char input[10];
void E();
void T();
void EDASH();
void TDASH();
void F();
int match(char,char);

int main()
{
	cout<<"Enter an expression"<<endl;
	cin>>input;
	E();
	if(strlen(input)==i and error==0)
	{
		cout<<"Expression is accepted"<<endl;
	}
	else
	{
		cout<<"Expression is not accepted"<<endl;
	}
}

void E()
{
	T();
	EDASH();
}
void EDASH()
{
	if(match(input[i],'+'))
	{
		i++;
		T();
		EDASH();
	}
}
void T()
{
	F();
	TDASH();
}
void TDASH()
{
	if(match(input[i],'*'))
	{
		i++;
		F();
		TDASH();
	}
}
void F()
{
	if(isalnum(input[i]))
	{
		i++;
	}
	else if(match(input[i],'('))
	{
		i++;
		E();
		if(match(input[i],')'))
		{
			i++;
		}
		else
		{
			error=1;
		}
	}
	else
	{
		error=1;
	}
}

int match(char a,char b)
{
	if(a==b)
		return 1;
	else
		return 0;
}
