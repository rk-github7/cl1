#include<stdio.h>
#include<string.h>
void main()
{
	//rk
	int a,b;
	char bilateral="s;
	a=3;
	c=a+d;
	int 9d;
	/*

scsmcml
*/

}
