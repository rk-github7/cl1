#include <stdio.h>
int main()
{
	c = a + b ;
}
