#include<stdio.h>
int main()
{
	int a,b,d;
	int c;
	c = a + b/d *6 ;
	if(a<b){
		c=a*d;
	}
	else{
		printf("sfaodllie");
	}
	
}
