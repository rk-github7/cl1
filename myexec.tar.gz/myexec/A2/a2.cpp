#include<iostream>
#include<pthread.h>
using namespace std;
int t;
class quick
{
	int low,high,piv_pos,n;
	int *arr;
	public:
	 quick(int n)
	{
		this->n=n;
		arr=new int[n];
		
	}
	quick(quick *obj)
	{
		n=obj->n;
		arr=obj->getArr();
	}
	int *getArr()
	{
		return arr;
	}
	 void accept()
	{
		cout<<"Enter "<<n<<" elements";
		for(int i=0;i<n;i++)
		{
			cin>>arr[i];
		}
		this->low=0;
		this->high=n-1;
		display(0,n-1);
	}
	void display(int l,int r)
	{
		cout<<"array elements are:";
		for(int i=l;i<=r;i++)
		{
			cout<<arr[i]<<" ";
		}
		cout<<endl;
	}
	void quickSort(int l,int r)
	{
		if(l<r)
		{
			
			piv_pos=partition(l,r);
			pthread_t t1,t2;			
			quick *p1,*p2;
			p1=new quick(this);
			p2=new quick(this);
			t++;
			cout<<"ID:"<<t<<endl;
			display(l,r);
			p1->low=l;
			p1->high=piv_pos-1;
			p2->low=piv_pos+1;
			p2->high=r;
			pthread_create(&t1,NULL,quick::thread_function,(void *)p1);
			pthread_create(&t2,NULL,quick::thread_function,(void *)p2);
			pthread_join(t1,NULL);
			pthread_join(t2,NULL);
			
		}
	}
	int partition(int l,int r)
	{
		//cout<<"In"<<endl;
		int pivot=arr[l];
		int i=l+1;
		int j=r;
		while(i<=j)
		{
			while(arr[i]<=pivot &&i<=r)
				i++;
			while(arr[j]>pivot && j>l)
				j--;
			if(i<j)
			{
				int temp=arr[i];
				arr[i]=arr[j];
				arr[j]=temp;
			}
		}
		arr[l]=arr[j];
		arr[j]=pivot;
		return j;
	}
	static void* thread_function(void *p)
	{
		quick* q=(quick *)p;
		q->quickSort(q->low,q->high);
	}
	
};
int main()
{
	cout<<"Enter the length of the array:"<<endl;
	int n;
	cin>>n;
	quick *p=new quick(n);
	p->accept();
	quick::thread_function((void *)p);
	cout<<"after Sorting:"<<endl;
	p->display(0,n-1);
	return 0;
}
