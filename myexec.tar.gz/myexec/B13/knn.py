import csv
import random
import math
import operator
def loadDataset(filename,training_set,testing_set,split):
	with open(filename,'rb') as csvfile:
		lines=csv.reader(csvfile)
		dataset=list(lines)
		for x in range(len(dataset)):
			for y in range(4):
				dataset[x][y]=float(dataset[x][y])
			if random.random()<split:
				training_set.append(dataset[x])
			else:
				testing_set.append(dataset[x])
def getEucDistance(traininginstance,testinginstance,l):
	distance=0;
	for x in range(l):
		distance += pow((traininginstance[x]-testinginstance[x]),2)
	return math.sqrt(distance)

def getNeighbors(testinginstance,training_set,k):
	distances=[];
	for x in range(len(training_set)):
		dist=getEucDistance(training_set[x],testinginstance,len(testinginstance)-1)
		distances.append((training_set[x],dist))
	distances.sort(key=operator.itemgetter(1))
	neighbors=[]
	for i in range(k):
		neighbors.append(distances[i][0])
	return neighbors
	
def getResponse(neighbors):
	voting={}
	for i in range(len(neighbors)):
		response=neighbors[i][-1]
		if response in voting:
			voting[response]+=1
		else:
			voting[response]=1
	sortedVotes=sorted(voting.items(),key=operator.itemgetter(1),reverse=True)
	return sortedVotes[0][0]
		
def main():
	training_set=[]
	testing_set=[]
	split=0.67777
	loadDataset("iris.data",training_set,testing_set,split)
	print "Training dataset:"+repr(len(training_set))
	print "Testing dataset:"+repr(len(testing_set))
	predictions=[]
	k=20
	accuracy=0
	for testinginstance in testing_set:
		neighbors=getNeighbors(testinginstance,training_set,k)
		response=getResponse(neighbors)
		predictions.append(response)
		print ("Predicted:"+repr(response)+"\tActual:"+repr(testinginstance[-1]))
		if response==testinginstance[-1]:
			accuracy+=1
	accuracy=(accuracy*100)/float(len(testing_set))
	
	print "Accuracy:"+repr(accuracy)
main()
	
