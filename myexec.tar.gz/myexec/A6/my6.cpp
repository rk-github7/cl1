#include<iostream>
#include<vector>
#include<math.h>
#include<algorithm>
using namespace std;



int main()
{
	int k,points,cenx,ceny;
	cout<<"Enter the number of clusters:"<<endl;
	cin>>k;
	cout<<"Enter the number of data points:"<<endl;
	cin>>points;
	double x[points],y[points];
	vector<int> *clusters,*prevclusters;
	clusters=new vector<int>[k];
	prevclusters=new vector<int>[k];
	for(int i=0;i<points;i++)
	{
		cin>>x[i]>>y[i];
	}
	vector<double> *centroids;
	centroids=new vector<double>[2];
	//new_centroids=new vector<double>[2];
	cout<<"Enter k cluster centroids"<<endl;
	
	for(int i=0;i<k;i++)
	{
		cin>>cenx>>ceny;
		centroids[0].push_back(cenx);
		centroids[1].push_back(ceny);
	}
	int count=0;
	bool redo=true;
	while(redo)
	{
		++count;
		//cout<<(++count)<<endl;
		
		for(int i=0;i<k;i++)
		{
			prevclusters[i].erase(prevclusters[i].begin(),prevclusters[i].end());
			for(int j=0;j<clusters[i].size();j++)
			{
				prevclusters[i].push_back(clusters[i][j]);
			
			}
			
			clusters[i].erase(clusters[i].begin(),clusters[i].end());
		}
		
		for(int i=0;i<points;i++)
		{
			double min=9999999;
			int pos=0;
			for(int j=0;j<k;j++)
			{
				double euc_dist=sqrt(pow((centroids[0][j]-x[i]),2)+pow((centroids[1][j]-y[i]),2));
				if(euc_dist<min)
				{
					min=euc_dist;
					pos=j;
				}
				
			}
			clusters[pos].push_back(i);
		}
		
		for(int i=0;i<k;i++)
		{
			double meanx=0,meany=0;
			for(int j=0;j<clusters[i].size();j++)
			{
				meanx+=x[clusters[i][j]];
				meany+=y[clusters[i][j]];
			} 
			centroids[0][i]=meanx/clusters[i].size();
			centroids[1][i]=meany/clusters[i].size();
		}
		
		for(int i=0;i<k;i++)
		{
			if(clusters[i].size()!=prevclusters[i].size())
			{
				cout<<"size unequal!!"<<endl;
				break;
			}
			else
			{
				bool flag=true;
			for(int j=0;j<clusters[i].size();j++)
			{
				if(prevclusters[i][j]!=clusters[i][j])
				{
					flag=false;
					break;
				}
			}
			if(flag)
			{
				redo=false;
			}
			} 
		}
	}
	
	for(int i=0;i<k;i++)
	{
		cout<<"data points of cluster "<<i<<"are:"<<endl;
		for(int j=0;j<clusters[i].size();j++)
		{
			cout<<x[clusters[i][j]]<<" , "<<y[clusters[i][j]]<<endl;
		}
		cout<<"centroid of cluster "<<i<<"is:"<<centroids[0][i]<<" , "<<centroids[1][i]<<endl;
	}
	
	
		
	return 0;
	

}
