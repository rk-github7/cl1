import json
N=8
def isAttack(board,row,col):
	for i in range(row):
		if board[i][col]==1:
			return True
	i=row-1
	j=col-1
	while(i>=0 and j>=0):
		if board[i][j]==1:
			return True
		i=i-1
		j=j-1
	i=row-1
	j=col+1
	while(i>=0 and j<N):
		if board[i][j]==1:
			return True
		i=i-1
		j=j+1
	return False
	
	
		
def solve(board,row):
	col=0
	display(board)
	for col in range(N):
		if(not isAttack(board,row,col)):
			board[row][col]=1
			if row==N-1:
				return True
			else:
				if solve(board,row+1):
					return True
				else:
					board[row][col]=0
	if col==N:
		return False
				


def display(board):
	for i in range(N):
		for j in range(N):
			print str(board[i][j])+" ",
		print "\n"
	print "\n"


board=[[0 for x in range(N)] for x in range(N)]

if __name__=='__main__':
	data=[]
	with open("input.json") as f:
		data=json.load(f)
	board[0][data["start"]]=1
	if solve(board,1):
		print N,"-Problem solved!!\n"
		print "Solution is as follows:"
		display(board)
	else:
		print "Problem cannot be solved for this position:"

