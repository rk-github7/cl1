class BinarySearch(var num:Int)
{
	var arr:Array[Int]=new Array[Int](num);
	
	var target:Int=0
	def input
	{
		println("Enter the "+num+" elements")
		for(i <- 0 to num-1)
		{
			arr(i)=readLine.toInt	
		}
		target=readLine("Enter value to be searched:").toInt
		scala.util.Sorting.quickSort(arr)
		display;
		
	}
	def display
	{
		println("Number found at position:"+search(0,num-1,target))
	}
	def search(l:Int,r:Int,x:Int):Int =
	{
		var mid:Int=(l+r)/2
		if(l<=r)
		{
			println("In:"+arr(mid)+" Target:"+x);
		if(arr(mid)==x)
			return mid+1
		else if(x>arr(mid))
			return search(mid+1,r,x)
		else
			return search(l,mid-1,x)
		}
		-1
	}
}
object BinSearch
{
	def main(args:Array[String])
	{
		var n:Int=0;
		n=readLine("Enter Number of elements").toInt
		var t1 =System.currentTimeMillis
		var obj=new BinarySearch(n)
		obj.input
		var t2 =System.currentTimeMillis
		println("Time Taken:"+(t2-t1));  
	}
}
