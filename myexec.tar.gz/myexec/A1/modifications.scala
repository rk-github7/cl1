import scala.language.postfixOps
import scala.io.Source

object BinarySearch {

	def binarysearch (nos: Array[Int], srno: Int, l: Int, r: Int): Int = {
		
		var mid = (l+r)/2
		if (l>r) {
			return -1;
		}
		else if (nos(mid)==srno) {
			return mid
		}
		else if (nos(mid)>srno) {
			binarysearch(nos, srno, l, mid-1)			
		}
		else {
			binarysearch(nos, srno, mid+1, r)
		}
	}

	// Manual sorting

object QuickSortScalaTime {
  def sortFunctional(xs: Array[Int]): Array[Int] = {
    if (xs.length <= 1) xs
    else {
      val pivot = xs(xs.length / 2)
      Array.concat(sortFunctional(xs filter (pivot >)), xs filter (pivot ==), sortFunctional(xs filter (pivot <)))
    }
  }

  def sortTraditionl(xs: Array[Int]) {
    def swap(i: Int, j: Int) {
      val t = xs(i);
      xs(i) = xs(j);
      xs(j) = t;
    }

    def sort1(l: Int, r: Int) {
      val pivot = xs((l + r) / 2)
      var i = l;
      var j = r;
      while (i <= j) {
        while (xs(i) < pivot) i += 1
        while (xs(j) > pivot) j -= 1
        if (i <= j) {
          swap(i, j)
          i += 1
          j -= 1
        }
      }
      if (l < j) sort1(l, j)
      if (j < r) sort1(i, r)
    }
    sort1(0, xs.length - 1)
  }

  // Time taken
  def main(args: Array[String]): Unit = {

    val arr = Array.fill(100000) { scala.util.Random.nextInt(100000 - 1) }
    var t1 = System.currentTimeMillis
    sortFunctional(arr)
    var t2 = System.currentTimeMillis
    println("Functional style : " + (t2-t1))

    t1 = System.currentTimeMillis
    sortTraditionl(arr)
    t2 = System.currentTimeMillis
    println("Traditional style : " + (t2-t1))
  }

}


// Random numbers

val z = Array.fill(1000)(10000).map(scala.util.Random.nextInt)
for (i <- 1 to 5) yield r.nextInt(100)

// Binary search methods

def binarySearchIterative(list: Array[Int], target: Int): Int = {
  var left = 0
  var right = list.length-1
  while (left<=right) {
    val mid = left + (right-left)/2
    if (list(mid)==target)
      return mid
    else if (list(mid)>target)
      right = mid-1
    else
      left = mid+1
    }
  -1
}

def binarySearchRecursive(list: Array[Int], target: Int)
                           (start: Int=0, end: Int=list.length-1): Int = {
  if (start>end) return -1
  val mid = start + (end-start+1)/2
  if (list(mid)==target)
    return mid
  else if (list(mid)>target)
    return binarySearchRecursive(list, target)(start, mid-1)
  else
    return binarySearchRecursive(list, target)(mid+1, end)
}


// Read from file

val lines = Source.fromFile("/Users/Al/.bash_profile").getLines.toList
val lines = Source.fromFile("/Users/Al/.bash_profile").getLines.toArray
val xs: List[Int] = args(0).split(' ').toList.map(_.toInt)
println(xs)


// Main from main code
	def main(args: Array[String]) {
		println("Enter number of elements in array: ")
		var n: Int = Console.readInt
		var nos = new Array[Int](n)
		println("Enter array elements: ")
		for (i <- 0 to n-1) {
			nos(i) = Console.readInt
		}
		nos = nos.sorted
		println("Enter number to be found: ")
		var srno: Int = Console.readInt
		var posn: Int = binarysearch(nos, srno, 0, n-1)
		if (posn == -1) {
			println ("Element not found.")
		}
		else {
			println ("Element found at position " +(posn+1)+" in sorted array.")
		}
	}
}
